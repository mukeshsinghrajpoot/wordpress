<?php 
//add_action( 'loop_start', 'your_function' );
add_filter('the_content', 'magentoproductpost_frontend_post');
function magentoproductpost_frontend_post() {
  global $post;
  $postid = get_the_ID();
  if ( is_single() && 'post' == get_post_type() ) 
  {
   /*wp_enqueue_style( 'bootstrap4.min',plugins_url( '/bootstrap/css/bootstrap4.min.css', __FILE__ ) );*/
   wp_enqueue_style( 'styles',plugins_url( '/bootstrap/css/custom1.css', __FILE__ ) );
   wp_enqueue_script( "magentoproductcurl", plugin_dir_url( __FILE__ ) . '/bootstrap/js/magentoproductcurl.js', 'jQuery','1.0.0', true );
    wp_localize_script( 'magentoproductcurl', 'magentoproductcurl_object', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
    echo do_shortcode(get_post_field('post_content', $postid));
     $sku=get_post_meta($post->ID, 'magento_sku', true); 
     echo '<form id="formoid" method="post">
            <div>
                <input type="hidden" id="sku2" name="name2"  value='.$sku.'>
           </div>
       </form>';
       echo '<div id="products11"></div>';
                    
  }else
  {
    echo do_shortcode(get_post_field('post_content', $postid));
  }
}