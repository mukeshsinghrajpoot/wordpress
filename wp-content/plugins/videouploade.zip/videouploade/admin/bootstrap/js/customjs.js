jQuery(document).ready(function() {
 jQuery("#tgroup").fadeTo(2000, 500).slideUp(500, function(){
 jQuery("#tgroup").slideUp(3000);
                });
});

